package com.todotogether.todo_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
